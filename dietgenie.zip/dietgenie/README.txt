DIETGENIE - NETLIFY READY STATIC WEBSITE

DEPLOYMENT
1. Unzip this package.
2. Drag the "dietgenie" folder into Netlify Drop, or upload its contents to a
   GitHub repository and connect that repository to Netlify.
3. No build command or publish configuration is required.

TECHNOLOGY
- HTML5
- CSS3
- Vanilla JavaScript
- Browser localStorage

OPTIONAL EDAMAM API
The website works immediately with its built-in meal recommendation catalogue.
To experiment with Edamam, open js/api.js and add the application ID and key.
For a real public website, API keys should be protected with a serverless
function rather than exposed in browser JavaScript.

IMPORTANT
DietGenie provides educational estimates only and is not medical advice.
