/*
  Optional Edamam integration.
  Add browser-safe credentials below only for a classroom demo. For a production
  site, API credentials should be protected behind a serverless function.
*/
window.DietGenieAPI = {
  EDAMAM_APP_ID: "",
  EDAMAM_APP_KEY: "",

  async searchMeals(query, calories) {
    if (!this.EDAMAM_APP_ID || !this.EDAMAM_APP_KEY) return null;
    const url = new URL("https://api.edamam.com/api/recipes/v2");
    url.searchParams.set("type", "public");
    url.searchParams.set("q", query);
    url.searchParams.set("app_id", this.EDAMAM_APP_ID);
    url.searchParams.set("app_key", this.EDAMAM_APP_KEY);
    url.searchParams.set("calories", Math.max(100, calories - 150) + "-" + (calories + 150));
    const response = await fetch(url);
    if (!response.ok) throw new Error("Meal service unavailable");
    return response.json();
  }
};
