(function () {
  const form = document.getElementById("bookingForm");
  if (!form) return;
  const STORAGE_KEY = "dietgenie_booking";
  const modal = document.getElementById("successModal");
  const dateInput = document.getElementById("appointmentDate");
  const today = new Date();
  const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split("T")[0];
  dateInput.min = localDate;

  try {
    const assessment = JSON.parse(localStorage.getItem("dietgenie_assessment"));
    if (assessment && assessment.fullName) document.getElementById("bookingName").value = assessment.fullName;
  } catch (error) {
    // A missing or malformed saved assessment should not block booking.
  }

  function value(name) {
    const field = form.elements[name];
    return field instanceof RadioNodeList ? field.value : field.value.trim();
  }

  function setError(name, message) {
    const error = form.querySelector('[data-error="' + name + '"]');
    const field = form.elements[name];
    if (error) error.textContent = message;
    if (field instanceof HTMLElement) field.classList.toggle("invalid", Boolean(message));
  }

  function validate() {
    const errors = {};
    if (value("fullName").length < 2) errors.fullName = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value("email"))) errors.email = "Enter a valid email address.";
    if (!/^[+\d][\d\s-]{7,16}$/.test(value("phone"))) errors.phone = "Enter a valid phone number.";
    if (!value("date") || value("date") < localDate) errors.date = "Choose today or a future date.";
    if (!value("time")) errors.time = "Choose an available time.";
    if (!value("type")) errors.type = "Choose a consultation type.";
    ["fullName", "email", "phone", "date", "time", "type"].forEach(function (name) { setError(name, errors[name] || ""); });
    return Object.keys(errors).length === 0;
  }

  form.addEventListener("input", function (event) {
    if (event.target.name) setError(event.target.name, "");
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (!validate()) return;
    const booking = {
      fullName: value("fullName"),
      email: value("email"),
      phone: value("phone"),
      date: value("date"),
      time: value("time"),
      type: value("type"),
      message: value("message"),
      reference: "DG-" + Date.now().toString().slice(-6),
      createdAt: new Date().toISOString()
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(booking));
    const formattedDate = new Date(booking.date + "T12:00:00").toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
    document.getElementById("confirmationDetails").innerHTML =
      "<div><span>Reference</span><strong>" + booking.reference + "</strong></div>" +
      "<div><span>Date</span><strong>" + formattedDate + "</strong></div>" +
      "<div><span>Time</span><strong>" + booking.time + "</strong></div>" +
      "<div><span>Format</span><strong>" + booking.type + "</strong></div>";
    modal.classList.add("open");
    document.body.style.overflow = "hidden";
  });

  function closeModal() {
    modal.classList.remove("open");
    document.body.style.overflow = "";
  }
  document.getElementById("closeModal").addEventListener("click", closeModal);
  modal.addEventListener("click", function (event) { if (event.target === modal) closeModal(); });
})();
