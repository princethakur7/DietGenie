(function () {
  const STORAGE_KEY = "dietgenie_assessment";
  const form = document.getElementById("assessmentForm");
  if (!form) return;

  const steps = Array.from(form.querySelectorAll(".form-step"));
  const labels = Array.from(document.querySelectorAll(".progress-labels span"));
  const progressFill = document.getElementById("progressFill");
  const progressPercent = document.getElementById("progressPercent");
  const stepLabel = document.getElementById("stepLabel");
  const prevBtn = document.getElementById("prevBtn");
  const nextBtn = document.getElementById("nextBtn");
  const submitBtn = document.getElementById("submitBtn");
  let currentStep = 0;

  const fieldsByStep = [
    ["fullName", "age", "gender"],
    ["height", "weight", "bodyType"],
    ["goal"],
    ["activityLevel", "mealsPerDay"],
    ["foodPreference", "budget"]
  ];

  const messages = {
    fullName: "Please enter at least 2 characters.",
    age: "Enter an age between 10 and 100.",
    gender: "Please select a gender.",
    height: "Enter a height between 100 and 250 cm.",
    weight: "Enter a weight between 30 and 300 kg.",
    bodyType: "Please select a body type.",
    goal: "Please select your main goal.",
    activityLevel: "Please select an activity level.",
    mealsPerDay: "Please select meals per day.",
    foodPreference: "Please select a food preference.",
    budget: "Please select a budget."
  };

  function getValue(name) {
    const elements = form.elements[name];
    if (!elements) return "";
    if (elements instanceof RadioNodeList) return elements.value;
    return elements.value.trim();
  }

  function isValid(name) {
    const value = getValue(name);
    if (!value) return false;
    const number = Number(value);
    if (name === "fullName") return value.length >= 2;
    if (name === "age") return number >= 10 && number <= 100;
    if (name === "height") return number >= 100 && number <= 250;
    if (name === "weight") return number >= 30 && number <= 300;
    return true;
  }

  function showError(name, valid) {
    const error = form.querySelector('[data-error="' + name + '"]');
    const input = form.elements[name];
    if (error) error.textContent = valid ? "" : messages[name];
    if (input && input instanceof HTMLElement) input.classList.toggle("invalid", !valid);
  }

  function validateStep() {
    let valid = true;
    fieldsByStep[currentStep].forEach(function (name) {
      const fieldValid = isValid(name);
      showError(name, fieldValid);
      if (!fieldValid) valid = false;
    });
    return valid;
  }

  function updateView() {
    steps.forEach(function (step, index) { step.classList.toggle("active", index === currentStep); });
    labels.forEach(function (label, index) { label.classList.toggle("active", index <= currentStep); });
    const percentage = ((currentStep + 1) / steps.length) * 100;
    progressFill.style.width = percentage + "%";
    progressPercent.textContent = Math.round(percentage) + "%";
    stepLabel.textContent = "Step " + (currentStep + 1) + " of " + steps.length;
    prevBtn.disabled = currentStep === 0;
    nextBtn.classList.toggle("hidden", currentStep === steps.length - 1);
    submitBtn.classList.toggle("hidden", currentStep !== steps.length - 1);
    form.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function collectData() {
    const data = {};
    new FormData(form).forEach(function (value, key) {
      if (key === "allergies") {
        if (!data.allergies) data.allergies = [];
        data.allergies.push(value);
      } else {
        data[key] = value;
      }
    });
    data.allergies = data.allergies || [];
    return data;
  }

  function saveDraft() {
    const data = collectData();
    data.savedAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }

  function loadDraft() {
    let data;
    try { data = JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch (error) { data = null; }
    if (!data) return;
    Object.keys(data).forEach(function (name) {
      if (name === "allergies" && Array.isArray(data[name])) {
        data[name].forEach(function (value) {
          const input = form.querySelector('[name="allergies"][value="' + value + '"]');
          if (input) input.checked = true;
        });
        return;
      }
      const input = form.querySelector('[name="' + name + '"][value="' + data[name] + '"]') || form.elements[name];
      if (!input) return;
      if (input.type === "radio" || input.type === "checkbox") input.checked = true;
      else if (!(input instanceof RadioNodeList)) input.value = data[name];
    });
  }

  function calculateNutrition(data) {
    const age = Number(data.age);
    const height = Number(data.height);
    const weight = Number(data.weight);
    const baseOffset = data.gender === "male" ? 5 : data.gender === "female" ? -161 : -78;
    const bmr = (10 * weight) + (6.25 * height) - (5 * age) + baseOffset;
    const activity = { sedentary: 1.2, moderate: 1.375, active: 1.55, athlete: 1.725 };
    const tdee = bmr * (activity[data.activityLevel] || 1.2);
    const goalAdjust = { "fat-loss": -400, "muscle-gain": 300, maintenance: 0 };
    const calories = Math.max(1200, Math.round(tdee + goalAdjust[data.goal]));
    let ratios = data.goal === "muscle-gain" ? [0.30, 0.45, 0.25] : data.goal === "fat-loss" ? [0.35, 0.35, 0.30] : [0.25, 0.45, 0.30];
    if (data.bodyType === "ectomorph") ratios = [ratios[0], ratios[1] + .05, ratios[2] - .05];
    if (data.bodyType === "endomorph") ratios = [ratios[0] + .05, ratios[1] - .10, ratios[2] + .05];
    return {
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      targetCalories: calories,
      protein: Math.round((calories * ratios[0]) / 4),
      carbs: Math.round((calories * ratios[1]) / 4),
      fat: Math.round((calories * ratios[2]) / 9),
      proteinPercent: Math.round(ratios[0] * 100),
      carbsPercent: Math.round(ratios[1] * 100),
      fatPercent: Math.round(ratios[2] * 100),
      bmi: Math.round((weight / Math.pow(height / 100, 2)) * 10) / 10
    };
  }

  nextBtn.addEventListener("click", function () {
    if (!validateStep()) return;
    saveDraft();
    currentStep += 1;
    updateView();
  });

  prevBtn.addEventListener("click", function () {
    if (currentStep > 0) currentStep -= 1;
    updateView();
  });

  form.addEventListener("input", function (event) {
    const name = event.target.name;
    if (messages[name]) showError(name, true);
    if (name === "allergies" && event.target.value === "none" && event.target.checked) {
      form.querySelectorAll('[name="allergies"]:not([value="none"])').forEach(function (box) { box.checked = false; });
    } else if (name === "allergies" && event.target.value !== "none" && event.target.checked) {
      const none = form.querySelector('[name="allergies"][value="none"]');
      if (none) none.checked = false;
    }
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    if (!validateStep()) return;
    const data = collectData();
    Object.assign(data, calculateNutrition(data), { completedAt: new Date().toISOString() });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    submitBtn.disabled = true;
    submitBtn.textContent = "Creating your plan...";
    setTimeout(function () { window.location.href = "meal-plan.html"; }, 650);
  });

  loadDraft();
  updateView();
})();
