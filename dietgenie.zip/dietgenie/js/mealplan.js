(function () {
  const STORAGE_KEY = "dietgenie_assessment";
  const planContent = document.getElementById("planContent");
  const emptyState = document.getElementById("emptyState");
  if (!planContent) return;

  let profile;
  try { profile = JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch (error) { profile = null; }
  if (!profile || !profile.completedAt) {
    planContent.classList.add("hidden");
    emptyState.classList.remove("hidden");
    return;
  }

  const fallbackMeals = {
    vegetarian: {
      breakfast: [
        ["Overnight Oats Bowl", "Oats, yogurt, berries, chia seeds, and cinnamon.", "🥣"],
        ["Paneer Veggie Toast", "Whole-grain toast with paneer, tomato, and spinach.", "🍞"],
        ["Poha Power Bowl", "Poha with peas, vegetables, lemon, and seeds.", "🥘"]
      ],
      lunch: [
        ["Rajma Rice Bowl", "Kidney beans, brown rice, cucumber, and fresh salad.", "🍛"],
        ["Paneer Quinoa Plate", "Grilled paneer, quinoa, greens, and mint yogurt.", "🥗"],
        ["Dal Roti Combo", "Mixed dal, whole-wheat roti, vegetables, and curd.", "🫓"]
      ],
      snack: [
        ["Fruit Yogurt Cup", "Greek yogurt, seasonal fruit, and pumpkin seeds.", "🍓"],
        ["Roasted Chana Mix", "Roasted chickpeas, cucumber, tomato, and lemon.", "🫘"],
        ["Hummus & Veggies", "Creamy hummus with carrots and cucumber sticks.", "🥕"]
      ],
      dinner: [
        ["Palak Paneer Plate", "Spinach paneer, millet roti, and crunchy salad.", "🥬"],
        ["Veggie Khichdi", "Moong dal khichdi with vegetables and cooling raita.", "🍲"],
        ["Chickpea Buddha Bowl", "Chickpeas, roasted vegetables, greens, and tahini.", "🥙"]
      ]
    },
    vegan: {
      breakfast: [
        ["Peanut Banana Oats", "Oats, banana, peanut butter, seeds, and plant milk.", "🥣"],
        ["Tofu Breakfast Wrap", "Spiced tofu, vegetables, and whole-wheat wrap.", "🌯"],
        ["Fruit Chia Pudding", "Chia pudding with mango, berries, and coconut.", "🥭"]
      ],
      lunch: [
        ["Chana Quinoa Bowl", "Chickpeas, quinoa, greens, vegetables, and lemon.", "🥗"],
        ["Lentil Curry Plate", "Masoor dal, brown rice, and seasonal vegetables.", "🍛"],
        ["Tofu Millet Bowl", "Grilled tofu, millet, spinach, and sesame dressing.", "🥙"]
      ],
      snack: [
        ["Roasted Makhana", "Crunchy fox nuts with fruit and herbal tea.", "🍿"],
        ["Hummus Crunch Cup", "Hummus, cucumber, carrots, and roasted chickpeas.", "🥕"],
        ["Seed Energy Bites", "Dates, oats, sunflower seeds, and cocoa.", "⚡"]
      ],
      dinner: [
        ["Tofu Stir-Fry", "Tofu, colorful vegetables, and brown rice.", "🥦"],
        ["Lentil Soup & Toast", "Hearty lentil soup with whole-grain toast.", "🍲"],
        ["Bean Burrito Bowl", "Beans, corn, rice, salsa, lettuce, and avocado.", "🌯"]
      ]
    },
    "non-vegetarian": {
      breakfast: [
        ["Egg & Avocado Toast", "Eggs, avocado, whole-grain toast, and tomato.", "🍳"],
        ["Chicken Breakfast Wrap", "Lean chicken, eggs, spinach, and wheat wrap.", "🌯"],
        ["Protein Oats Bowl", "Oats, yogurt, fruit, seeds, and boiled eggs.", "🥣"]
      ],
      lunch: [
        ["Grilled Chicken Bowl", "Herb chicken, brown rice, greens, and vegetables.", "🍗"],
        ["Fish Curry Plate", "Light fish curry, rice, vegetables, and salad.", "🐟"],
        ["Chicken Roti Meal", "Chicken curry, whole-wheat roti, and cucumber salad.", "🍛"]
      ],
      snack: [
        ["Egg & Fruit Plate", "Boiled eggs with seasonal fruit and seeds.", "🥚"],
        ["Chicken Salad Cup", "Shredded chicken, lettuce, cucumber, and yogurt dip.", "🥗"],
        ["Yogurt Berry Bowl", "Greek yogurt, berries, and toasted seeds.", "🫐"]
      ],
      dinner: [
        ["Herb Fish & Veggies", "Grilled fish, roasted vegetables, and sweet potato.", "🐟"],
        ["Chicken Quinoa Plate", "Lean chicken, quinoa, greens, and mint dressing.", "🍗"],
        ["Egg Curry Dinner", "Egg curry, millet roti, and sautéed vegetables.", "🥚"]
      ]
    }
  };
  fallbackMeals.eggetarian = {
    breakfast: fallbackMeals["non-vegetarian"].breakfast,
    lunch: [
      ["Egg Curry Rice Bowl", "Egg curry, brown rice, vegetables, and salad.", "🥚"],
      ["Paneer Egg Protein Plate", "Eggs, paneer, quinoa, and sautéed greens.", "🍳"],
      ["Masala Egg Roti", "Spiced eggs, whole-wheat roti, and cucumber salad.", "🫓"]
    ],
    snack: fallbackMeals["non-vegetarian"].snack,
    dinner: [
      ["Egg Bhurji Plate", "Egg bhurji, millet roti, and mixed vegetables.", "🍳"],
      ["Vegetable Frittata", "Egg and vegetable frittata with roasted potatoes.", "🥚"],
      ["Dal & Egg Bowl", "Lentils, boiled eggs, brown rice, and fresh greens.", "🍲"]
    ]
  };

  const types = ["breakfast", "lunch", "snack", "dinner"];
  let variation = Math.floor(Math.random() * 3);

  function text(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
  }

  function title(value) {
    return String(value || "").replace(/-/g, " ").replace(/\b\w/g, function (letter) { return letter.toUpperCase(); });
  }

  function estimateMeal(type, index) {
    const ratios = { breakfast: .25, lunch: .32, snack: .13, dinner: .30 };
    const adjustment = [0, 12, -8][index % 3];
    const calories = Math.round(profile.targetCalories * ratios[type]) + adjustment;
    return {
      calories: calories,
      protein: Math.round(profile.protein * ratios[type]),
      carbs: Math.round(profile.carbs * ratios[type]),
      fat: Math.round(profile.fat * ratios[type])
    };
  }

  function renderMeals() {
    const preference = fallbackMeals[profile.foodPreference] ? profile.foodPreference : "vegetarian";
    const grid = document.getElementById("mealGrid");
    grid.innerHTML = "";
    types.forEach(function (type, index) {
      const meal = fallbackMeals[preference][type][(variation + index) % 3];
      const macro = estimateMeal(type, index);
      const article = document.createElement("article");
      article.className = "meal-card";
      article.innerHTML =
        '<div class="meal-top"><span class="meal-type">' + type + '</span><span class="meal-emoji">' + meal[2] + '</span></div>' +
        '<div class="meal-body"><h3>' + meal[0] + '</h3><p>' + meal[1] + '</p>' +
        '<div class="meal-macros"><span>' + macro.calories + ' kcal</span><span>' + macro.protein + 'g protein</span><span>' + macro.carbs + 'g carbs</span><span>' + macro.fat + 'g fat</span></div></div>';
      grid.appendChild(article);
    });
  }

  function render() {
    const firstName = String(profile.fullName || "Your").split(" ")[0];
    text("greetingName", firstName + "’s");
    text("planSummary", "Designed for " + title(profile.goal) + " with a " + title(profile.foodPreference) + " food preference.");
    text("calories", profile.targetCalories);
    text("protein", profile.protein);
    text("carbs", profile.carbs);
    text("fat", profile.fat);
    text("profileGoal", title(profile.goal));
    text("profileBmi", profile.bmi);
    text("profileActivity", title(profile.activityLevel));
    text("profileMeals", profile.mealsPerDay + " per day");
    text("preferenceBadge", title(profile.foodPreference));
    text("proteinPercent", profile.proteinPercent + "%");
    text("carbsPercent", profile.carbsPercent + "%");
    text("fatPercent", profile.fatPercent + "%");
    text("donutProtein", profile.proteinPercent + "%");
    document.getElementById("proteinBar").style.width = Math.min(100, profile.proteinPercent * 2) + "%";
    document.getElementById("carbsBar").style.width = Math.min(100, profile.carbsPercent * 2) + "%";
    document.getElementById("fatBar").style.width = Math.min(100, profile.fatPercent * 2) + "%";
    document.getElementById("macroDonut").style.background =
      "conic-gradient(#8b5cf6 0 " + profile.proteinPercent + "%, #0ea5e9 " + profile.proteinPercent + "% " +
      (profile.proteinPercent + profile.carbsPercent) + "%, #f59e0b " + (profile.proteinPercent + profile.carbsPercent) + "% 100%)";
    const tips = {
      "fat-loss": "Build half your plate with vegetables and eat slowly enough to notice fullness.",
      "muscle-gain": "Spread protein across the day and pair training with enough sleep and hydration.",
      maintenance: "Consistency matters more than perfection. Keep your favorite foods in balanced portions."
    };
    text("dailyTip", tips[profile.goal]);
    renderMeals();
  }

  document.getElementById("regenerateBtn").addEventListener("click", function () {
    variation = (variation + 1) % 3;
    renderMeals();
  });
  setTimeout(render, 350);
})();
